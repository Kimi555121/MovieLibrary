﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieLibrary
{
    public partial class SearchingForm : Form
    {
        public SearchingForm()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string movieTitle = textBox1.Text.ToLower().Trim();
            List<Movie> movieList = new List<Movie>();
            movieList = SearchedMovies(movieTitle, movieList);
            this.Hide();
            if (movieList.Count == 0)
            {
                MainForm mainForm = new MainForm();
                mainForm.Show();
            }
            else
            {
                MainForm mainForm = new MainForm(movieList);
                mainForm.Show();
            }
        }


        private List<Movie> SearchedMovies(string movieTitle, List<Movie> movieList)
        {
            string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";

            try
            {
                List<string> lines = new List<string>(File.ReadAllLines(filePath));
                bool movieFound = false;

                for (int i = 0; i < lines.Count; i++)
                {
                    string[] columns = lines[i].Split(',');
                    if (columns.Length > 0 && columns[0].Trim().Contains(movieTitle, StringComparison.OrdinalIgnoreCase))
                    {
                        movieFound = true;
                        movieList.Add(new Movie(columns[0], columns[1], int.Parse(columns[2]), columns[3], columns[4]));
                    }
                }

                if (movieFound)
                {
                    return movieList;
                }
                else
                {
                    MessageBox.Show($"No movie with a title {movieTitle} has been found in the file.", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return movieList;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return movieList;
            }
        }

    }
}
