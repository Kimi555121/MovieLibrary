﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieLibrary
{
    internal class LogicClass
    {
        string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";
        public void UpdateList(ListBox listBoxMovies)
        {
            listBoxMovies.Items.Clear();
            



            var movies = new List<Movie>();
            string[] lines = File.ReadAllLines(filePath);


            for (int i = 0; i < lines.Length; i++)
            {
                string[] fields = lines[i].Split(',');
                movies.Add(new Movie(fields[0], fields[1], int.Parse(fields[2]), fields[3], fields[4]));
            }

            foreach (var movie in movies)
            {
                listBoxMovies.Items.Add(movie.Title.ToString());
            }

        }


        public void UpdateSearchedList(List<Movie> movies, ListBox listBoxMovies)
        {
            listBoxMovies.Items.Clear();
            
            foreach (var movie in movies)
            {
                listBoxMovies.Items.Add(movie.Title.ToString());
            }

        }



        public void DeleteMovie(string movieTitle)
        {
            

            try
            {
                // Read all lines from the CSV file
                List<string> lines = new List<string>(File.ReadAllLines(filePath));
                bool movieFound = false;

                // Remove the line that contains the matching movie title
                for (int i = 0; i < lines.Count; i++)
                {
                    string[] columns = lines[i].Split(',');
                    if (columns.Length > 0 && columns[0].Trim().Equals(movieTitle, StringComparison.OrdinalIgnoreCase))
                    {
                        lines.RemoveAt(i);
                        movieFound = true;
                        break; // Exit the loop after deleting the movie
                    }
                }

                if (movieFound)
                {
                    // Write the updated lines back to the file
                    File.WriteAllLines(filePath, lines);
                    MessageBox.Show($"The movie {movieTitle} has been deleted successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                }
                else
                {
                    MessageBox.Show($"The movie {movieTitle} has not been found in the file.", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }


    }
}
