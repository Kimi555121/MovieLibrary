﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieLibrary
{
    public class Movie
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public Movie(string title, string genre, int year, string description, string image)
        {
            this.Title = title;
            this.Genre = genre;
            this.Year = year;
            this.Description = description;
            this.Image = image;  
        }
    }
}
