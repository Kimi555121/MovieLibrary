﻿namespace MovieLibrary
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            btnAdd = new Button();
            label1 = new Label();
            listBoxMovies = new ListBox();
            btnDelete = new Button();
            btnView = new Button();
            btnSearch = new Button();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Showcard Gothic", 30F, FontStyle.Regular, GraphicsUnit.Point);
            btnAdd.Location = new Point(263, 210);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(231, 140);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Kunstler Script", 60F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(137, 49);
            label1.Name = "label1";
            label1.Size = new Size(470, 108);
            label1.TabIndex = 1;
            label1.Text = "Movie Library";
            // 
            // listBoxMovies
            // 
            listBoxMovies.Font = new Font("Times New Roman", 10F, FontStyle.Regular, GraphicsUnit.Point);
            listBoxMovies.FormattingEnabled = true;
            listBoxMovies.ItemHeight = 19;
            listBoxMovies.Location = new Point(12, 210);
            listBoxMovies.Name = "listBoxMovies";
            listBoxMovies.Size = new Size(245, 289);
            listBoxMovies.TabIndex = 2;
            // 
            // btnDelete
            // 
            btnDelete.Font = new Font("Showcard Gothic", 30F, FontStyle.Regular, GraphicsUnit.Point);
            btnDelete.Location = new Point(500, 356);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(262, 143);
            btnDelete.TabIndex = 3;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnView
            // 
            btnView.Font = new Font("Showcard Gothic", 30F, FontStyle.Regular, GraphicsUnit.Point);
            btnView.Location = new Point(263, 356);
            btnView.Name = "btnView";
            btnView.Size = new Size(231, 143);
            btnView.TabIndex = 4;
            btnView.Text = "View";
            btnView.UseVisualStyleBackColor = true;
            btnView.Click += btnView_Click;
            // 
            // btnSearch
            // 
            btnSearch.Font = new Font("Showcard Gothic", 30F, FontStyle.Regular, GraphicsUnit.Point);
            btnSearch.Location = new Point(500, 210);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(262, 140);
            btnSearch.TabIndex = 5;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(768, 506);
            Controls.Add(btnSearch);
            Controls.Add(btnView);
            Controls.Add(btnDelete);
            Controls.Add(listBoxMovies);
            Controls.Add(label1);
            Controls.Add(btnAdd);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "MainForm";
            Text = "MainForm";
            FormClosing += MainForm_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAdd;
        private Label label1;
        private ListBox listBoxMovies;
        private Button btnDelete;
        private Button btnView;
        private Button btnSearch;
    }
}