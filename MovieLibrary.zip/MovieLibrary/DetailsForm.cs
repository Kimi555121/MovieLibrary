﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieLibrary
{
    public partial class DetailsForm : Form
    {
        public DetailsForm(string movieTitle)
        {

            InitializeComponent();
            Movie movie = FindTheMovie(movieTitle);
            DisplayDetails(movie);

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private Movie FindTheMovie(string title)
        {
            string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";
            string[] lines = File.ReadAllLines(filePath);

            for (int i = 0; i < lines.Length; i++)
            {
                string[] fields = lines[i].Split(',');
                if (title == fields[0])
                {
                    return new Movie(fields[0], fields[1], int.Parse(fields[2]), fields[3], fields[4]);
                }
            }
            return new Movie("", "", 0, "", "");
        }



        private void DisplayDetails(Movie movie)
        {
            lblTitle.Text = movie.Title;
            lblGenre.Text = movie.Genre;
            lblYear.Text = movie.Year.ToString();
            lblDescription.Text = movie.Description;


            try
            {
                using (WebClient client = new WebClient())
                {
                    // Download the image
                    byte[] imageData = client.DownloadData(movie.Image);
                    using (var stream = new System.IO.MemoryStream(imageData))
                    {
                        pictureBox1.Image = Image.FromStream(stream); // Load the image into PictureBox
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load the image: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }





        }

        private void DetailsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }
    }
}
