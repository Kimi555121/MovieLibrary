﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieLibrary
{
    public partial class AddingForm : Form
    {
        public AddingForm()
        {
            InitializeComponent();
        }

        public void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Movie newMovie = new Movie(textBox1.Text.ToString(), textBox2.Text.ToString(), Convert.ToInt32(textBox3.Text), textBoxDescription.Text.ToString(), textBox4.Text.ToString());
                AddMovieToFile(newMovie);
                MessageBox.Show($"The movie {newMovie.Title} has been deleted successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            MainForm mainForm = new MainForm();
            this.Close();
            mainForm.ShowDialog();
        }

        private void AddMovieToFile(Movie movie)
        {
            string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";
            string movieData = $"{movie.Title.Trim()},{movie.Genre},{movie.Year.ToString()},{movie.Description},{movie.Image}\n";

            if (!File.Exists(filePath))
            {
                CreateCsvFile(filePath);
            }

            File.AppendAllText(filePath, movieData);


        }

        private void CreateCsvFile(string filePath)
        {
            File.WriteAllText(filePath, string.Empty);
        }

        private void AddingForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }
    }
}
