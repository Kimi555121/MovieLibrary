﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieLibrary
{
    public partial class AddingForm : Form
    {
        public AddingForm()
        {
            InitializeComponent();
        }

        public void btnAdd_Click(object sender, EventArgs e)
        {
            Movie newMovie = new Movie(textBox1.Text.ToString(), textBox2.Text.ToString(), Convert.ToInt32(textBox3.Text), textBoxDescription.Text.ToString(), textBox4.Text.ToString());
            AddMovieToFile(newMovie);
            AddedDialog addedDialog = new AddedDialog();
            this.Close();
            addedDialog.ShowDialog();
        }

        private void AddMovieToFile(Movie movie)
        {
            string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";
            string movieData = $"{movie.Title.Trim()},{movie.Genre.Trim()},{movie.Year.ToString().Trim()},{movie.Description.ToString()}\n";

            if (!File.Exists(filePath))
            {
                CreateCsvFile(filePath);
            }

            File.AppendAllText(filePath, movieData);


        }

        private void CreateCsvFile(string filePath)
        {
            File.WriteAllText(filePath, string.Empty);
        }


    }
}
