using System.Media;

namespace MovieLibrary
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            UpdateList();

        }

        public MainForm(List<Movie> movies)
        {
            InitializeComponent();
            UpdateSearchedList(movies);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddingForm addingForm = new AddingForm();
            this.Hide();
            addingForm.Show();

        }

        private void btnView_Click(object sender, EventArgs e)
        {
            DetailsForm detailsForm = new DetailsForm(listBoxMovies.SelectedItem.ToString());
            this.Hide();
            detailsForm.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string movieTitle = listBoxMovies.SelectedItem.ToString();
            DeleteMovie(movieTitle);
            UpdateList();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchingForm searchingForm = new SearchingForm();
            this.Hide();
            searchingForm.Show();
        }

        private void DeleteMovie(string movieTitle)
        {
            string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";


            try
            {
                // Read all lines from the CSV file
                List<string> lines = new List<string>(File.ReadAllLines(filePath));
                bool movieFound = false;

                // Remove the line that contains the matching movie title
                for (int i = 0; i < lines.Count; i++)
                {
                    string[] columns = lines[i].Split(',');
                    if (columns.Length > 0 && columns[0].Trim().Equals(movieTitle, StringComparison.OrdinalIgnoreCase))
                    {
                        lines.RemoveAt(i);
                        movieFound = true;
                        break; // Exit the loop after deleting the movie
                    }
                }

                if (movieFound)
                {
                    // Write the updated lines back to the file
                    File.WriteAllLines(filePath, lines);
                    MessageBox.Show($"The movie {movieTitle} has been deleted successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                }
                else
                {
                    MessageBox.Show($"The movie {movieTitle} has not been found in the file.", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }



        private void UpdateList()
        {
            listBoxMovies.Items.Clear();
            string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";



            var movies = new List<Movie>();
            string[] lines = File.ReadAllLines(filePath);


            for (int i = 0; i < lines.Length; i++)
            {
                string[] fields = lines[i].Split(',');
                // if (fields.Length == 5)
                //{
                movies.Add(new Movie(fields[0], fields[1], int.Parse(fields[2]), fields[3], fields[4]));
                //}
            }

            foreach (var movie in movies)
            {
                listBoxMovies.Items.Add(movie.Title.ToString());
            }

        }


        public void UpdateSearchedList(List<Movie> movies)
        {
            listBoxMovies.Items.Clear();
            string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";

            foreach (var movie in movies)
            {
                listBoxMovies.Items.Add(movie.Title.ToString());
            }

        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        
    }
}