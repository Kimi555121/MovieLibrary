using System.Media;

namespace MovieLibrary
{
    public partial class MainForm : Form
    {

        LogicClass logicClass = new LogicClass();

        public MainForm()
        {
            InitializeComponent();
            logicClass.UpdateList(listBoxMovies);
        }

        public MainForm(List<Movie> movies)
        {
            InitializeComponent();
            logicClass.UpdateSearchedList(movies, listBoxMovies);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddingForm addingForm = new AddingForm();
            this.Hide();
            addingForm.Show();
        }

        private void btnView_Click(object sender, EventArgs e)
        {

            if (listBoxMovies.SelectedItem != null)
            {
                DetailsForm detailsForm = new DetailsForm(listBoxMovies.SelectedItem.ToString());
                this.Hide();
                detailsForm.Show();
            }
            else
            {
                MessageBox.Show("You didn't select anything.. baka!");
            }

            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (listBoxMovies.SelectedItem != null)
            {
                string movieTitle = listBoxMovies.SelectedItem.ToString();
                logicClass.DeleteMovie(movieTitle);
                logicClass.UpdateList(listBoxMovies);
            }
            else
            {
                MessageBox.Show("You didn't select anything.. baka!");
            }

            
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchingForm searchingForm = new SearchingForm();
            this.Hide();
            searchingForm.Show();
        }

        



        

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        
    }
}