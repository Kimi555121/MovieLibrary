namespace MovieLibrary
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            UpdateList();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddingForm addingForm = new AddingForm();
            this.Hide();
            addingForm.Show();

        }

        private void btnView_Click(object sender, EventArgs e)
        {
            DetailsForm detailsForm = new DetailsForm(listBoxMovies.SelectedItem.ToString());
            this.Hide();
            detailsForm.Show();
        }



        private void UpdateList()
        {
            listBoxMovies.Items.Clear();
            string filePath = Directory.GetCurrentDirectory() + @"\filepath\moviesFilePath.csv";



            var movies = new List<Movie>();
            string[] lines = File.ReadAllLines(filePath);


            for (int i = 0; i < lines.Length; i++)
            {
                string[] fields = lines[i].Split(',');
                // if (fields.Length == 5)
                //{
                    movies.Add(new Movie(fields[0], fields[1], int.Parse(fields[2]), fields[3], fields[4]));
                //}
            }

            foreach (var movie in movies)
            {
                listBoxMovies.Items.Add(movie.Title.ToString());
            }

        }

        
    }
}